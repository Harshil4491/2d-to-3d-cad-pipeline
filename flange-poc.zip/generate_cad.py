import json
import os
import glob
from build123d import (
    Align,
    BuildPart, Cylinder, Locations, PolarLocations, Mode, export_step, Axis
)

def find_feature(features, feature_type):
    for f in features:
        if f.get("feature_type") == feature_type:
            return f
    return None


def build_flange(data, out_path, log):
    result = data["result"]
    bf = result["base_feature"]
    features = result.get("features", [])

    outer_d = bf["outer_diameter"]
    thickness = bf["overall_thickness"]
    total_height = bf.get("total_height") or thickness
    bore_d = bf.get("bore_diameter")
    bolt_circle_d = result.get("bolt_circle_diameter")

    hub_height = max(total_height - thickness, 0)
    hub_feature = find_feature(features, "hub")
    bolt_feature = find_feature(features, "bolt_holes")

    warnings = []

    with BuildPart() as flange:
        Cylinder(radius=outer_d / 2, height=thickness)

        if hub_height > 0:
            if hub_feature and hub_feature.get("value"):
                hub_d = hub_feature["value"]
                if hub_d >= outer_d:
                    warnings.append(f"Hub diameter {hub_d} >= outer diameter {outer_d} - implausible, hub skipped")
                    hub_d = None
            else:
                hub_d = None
                warnings.append("total_height exceeds thickness but no hub feature found - hub NOT generated, needs engineer review")

            if hub_d:
                # base disk is centered on z=0, so its top face is at +thickness/2.
                # place hub centered so it starts at the top face and rises upward,
                # with a small overlap into the disk to guarantee a fused solid.
                overlap = min(thickness * 0.25, hub_height * 0.25)
                hub_total = hub_height + overlap
                hub_center_z = thickness / 2 - overlap + hub_total / 2
                with Locations((0, 0, hub_center_z)):
                    Cylinder(radius=hub_d / 2, height=hub_total)
        rf_d = bf.get("raised_face_diameter")
        rf_h = bf.get("raised_face_height")
        if rf_d and rf_h:
            overlap = min(rf_h * 0.5, thickness * 0.25)
            rf_total = rf_h + overlap
            rf_center_z = thickness / 2 - overlap + rf_total / 2
            with Locations((0, 0, rf_center_z)):
                Cylinder(radius=rf_d / 2, height=rf_total)


        if bore_d:
            with Locations((0, 0, 0)):
                Cylinder(radius=bore_d / 2, height=total_height * 2 + 1,
                          mode=Mode.SUBTRACT)

        if bolt_feature and bolt_circle_d:
            count = bolt_feature.get("quantity") or 4
            hole_d = bolt_feature.get("value")
            if hole_d:
                with PolarLocations(radius=bolt_circle_d / 2, count=count):
                    Cylinder(radius=hole_d / 2, height=thickness * 2 + 1,
                              mode=Mode.SUBTRACT)
            else:
                warnings.append("bolt_holes feature had no diameter value - bolt holes skipped")
        elif bolt_circle_d and not bolt_feature:
            warnings.append("bolt_circle_diameter present but no bolt_holes feature - holes skipped")

    export_step(flange.part, out_path)

    log["volume"] = flange.part.volume
    log["warnings"] = warnings
    return flange.part


def run_batch(extracted_dir="extracted", output_dir="cad_output"):
    os.makedirs(output_dir, exist_ok=True)
    json_files = sorted(glob.glob(os.path.join(extracted_dir, "*.json")))
    json_files = [f for f in json_files if not f.endswith("_summary.json")]
    json_files = [f for f in json_files if not f.endswith(".original.json")]

    results = []

    for path in json_files:
        name = os.path.splitext(os.path.basename(path))[0]
        with open(path) as f:
            data = json.load(f)

        if "error" in data or not data.get("schema_valid", False):
            print(f"[SKIP] {name} - no valid extraction to build from")
            results.append({"drawing": name, "status": "SKIPPED", "reason": "invalid extraction"})
            continue

        out_step = os.path.join(output_dir, f"{name}.step")
        log = {}
        try:
            build_flange(data, out_step, log)
            status = "OK" if not log["warnings"] else "OK_WITH_WARNINGS"
            print(f"[{status}] {name}  volume={log['volume']:.3f}")
            for w in log["warnings"]:
                print(f"    - {w}")
            results.append({
                "drawing": name, "status": status, "volume": log["volume"],
                "warnings": log["warnings"], "step_file": out_step
            })
        except Exception as e:
            print(f"[FAIL] {name}  {e}")
            results.append({"drawing": name, "status": "FAIL", "error": str(e)})

    with open(os.path.join(output_dir, "_generation_summary.json"), "w") as f:
        json.dump(results, f, indent=2)

    n_ok = sum(1 for r in results if r["status"].startswith("OK"))
    n_fail = sum(1 for r in results if r["status"] == "FAIL")
    n_skip = sum(1 for r in results if r["status"] == "SKIPPED")
    print(f"\nDone: {n_ok} generated, {n_fail} failed, {n_skip} skipped")
    print(f"STEP files in: {output_dir}/")


if __name__ == "__main__":
    run_batch()
