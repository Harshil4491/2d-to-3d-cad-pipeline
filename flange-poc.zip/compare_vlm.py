import base64
import json
import os
import glob
import re
import time
import io
from pdf2image import convert_from_path
from PIL import Image
from openai import OpenAI

client = OpenAI(base_url='http://localhost:8000/v1', api_key='EMPTY')

COMPARISON_SCHEMA = {
    "type": "object",
    "properties": {
        "overall_match": {"type": "string", "enum": ["good_match", "minor_mismatch", "major_mismatch"]},
        "confidence": {"type": "string", "enum": ["high", "medium", "low"]},
        "mismatches": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "category": {"type": "string", "enum": ["missing_feature", "extra_feature", "wrong_count", "wrong_proportion", "wrong_shape", "orientation", "other"]},
                    "severity": {"type": "string", "enum": ["critical", "moderate", "minor"]},
                    "description": {"type": "string"}
                },
                "required": ["category", "severity", "description"]
            }
        },
        "summary": {"type": "string"}
    },
    "required": ["overall_match", "confidence", "mismatches", "summary"]
}

PROMPT = """You are a mechanical engineering QA reviewer. You are shown TWO images:

IMAGE 1: the original 2D engineering drawing of a flange.
IMAGE 2: three rendered views (isometric, front, top) of a 3D CAD model that was automatically generated from that drawing.

Your job: decide whether the 3D model faithfully represents the drawing, and list any mismatches.

WORK THROUGH THESE STEPS BEFORE ANSWERING:
1. In IMAGE 1 (the drawing), count the bolt holes and note whether the part has a hub/neck sticking out, and whether it has a through bore.
2. In IMAGE 2 (the model), count the bolt holes and note whether it has a hub/neck, and whether it has a through bore.
3. Compare your two counts and observations directly. Any difference IS a mismatch and must be reported.
Do not answer "good_match" without having actually counted the holes in both images.

IMPORTANT CONTEXT about how the model was generated - do NOT report these as mismatches:
- The generator intentionally builds only: the base disk/ring, the central bore, the bolt hole pattern, and any hub/neck.
- It deliberately does NOT model: raised faces, RTJ grooves, threads, chamfers, or fillets. Their absence is expected and is NOT a mismatch.
- The model is untextured grey and has no dimensions or annotations. That is expected.

DO report mismatches such as:
- Bolt holes missing entirely, or an obviously different number of holes than the drawing shows
- A hub/neck present in the drawing but absent from the model (or vice versa)
- A through bore in the drawing but a solid model (or vice versa)
- Grossly wrong proportions (e.g. the model is a thin disk but the drawing shows a tall part)
- The model being a completely different shape family than the drawing

Rate overall_match as:
- "good_match": core geometry matches; only the intentionally-omitted details differ
- "minor_mismatch": mostly right, but something small is off
- "major_mismatch": a core feature is missing, wrong, or the shape is fundamentally different

Output ONLY the raw JSON object. No markdown code fences, no explanation before or after."""


def strip_fences(text):
    text = text.strip()
    text = re.sub(r'^```(?:json)?\s*', '', text)
    text = re.sub(r'\s*```$', '', text)
    return text.strip()


def img_to_b64(pil_img, max_dim=1400):
    w, h = pil_img.size
    if max(w, h) > max_dim:
        scale = max_dim / max(w, h)
        pil_img = pil_img.resize((int(w * scale), int(h * scale)), Image.LANCZOS)
    buf = io.BytesIO()
    pil_img.convert("RGB").save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode()


def compare_one(pdf_path, render_path):
    drawing_img = convert_from_path(pdf_path, dpi=200)[0]
    render_img = Image.open(render_path)

    drawing_b64 = img_to_b64(drawing_img)
    render_b64 = img_to_b64(render_img)

    response = client.chat.completions.create(
        model='Qwen/Qwen3.8-27B',
        messages=[{
            'role': 'user',
            'content': [
                {'type': 'text', 'text': PROMPT},
                {'type': 'text', 'text': 'IMAGE 1 - original 2D drawing:'},
                {'type': 'image_url', 'image_url': {'url': f'data:image/png;base64,{drawing_b64}'}},
                {'type': 'text', 'text': 'IMAGE 2 - rendered views of the generated 3D model:'},
                {'type': 'image_url', 'image_url': {'url': f'data:image/png;base64,{render_b64}'}},
            ]
        }],
        max_tokens=1536,
        temperature=0,
        extra_body={
            'chat_template_kwargs': {'enable_thinking': False},
        },
    )
    raw = response.choices[0].message.content
    return json.loads(strip_fences(raw))


def run_batch(dataset_dir="raw_dataset", renders_dir="renders", out_dir="comparison"):
    os.makedirs(out_dir, exist_ok=True)
    pdfs = sorted(glob.glob(os.path.join(dataset_dir, "*.pdf")))

    results = []
    print(f"Comparing {len(pdfs)} drawing/model pairs...\n")

    for i, pdf_path in enumerate(pdfs, 1):
        name = os.path.splitext(os.path.basename(pdf_path))[0]
        render_path = os.path.join(renders_dir, f"{name}.png")

        if not os.path.exists(render_path):
            print(f"[{i}/{len(pdfs)}] {name} - SKIP (no render)")
            continue

        print(f"[{i}/{len(pdfs)}] {name} ...", end=" ", flush=True)
        t0 = time.time()
        try:
            verdict = compare_one(pdf_path, render_path)
            elapsed = time.time() - t0
            raw_mm = verdict.get("mismatches", []) or []
            mismatches = [m if isinstance(m, dict) else {"category": "other", "severity": "moderate", "description": str(m)} for m in raw_mm]
            verdict["mismatches"] = mismatches
            n_mm = len(mismatches)
            critical = sum(1 for m in mismatches if m.get("severity") == "critical")
            print(f"{verdict.get('overall_match','unknown')}  ({n_mm} mismatches, {critical} critical) ({elapsed:.0f}s)")
            for m in mismatches:
                print(f"      [{m.get('severity','?')}] {m.get('category','?')}: {m.get('description','')}")

            with open(os.path.join(out_dir, f"{name}.json"), "w") as f:
                json.dump(verdict, f, indent=2)

            results.append({
                "drawing": name,
                "overall_match": verdict["overall_match"],
                "confidence": verdict.get("confidence", "unknown"),
                "n_mismatches": n_mm,
                "n_critical": critical,
                "summary": verdict.get("summary", ""),
                "seconds": round(elapsed, 1),
            })
        except Exception as e:
            elapsed = time.time() - t0
            print(f"ERROR: {e} ({elapsed:.0f}s)")
            results.append({"drawing": name, "overall_match": "ERROR", "error": str(e)})

    with open(os.path.join(out_dir, "_comparison_summary.json"), "w") as f:
        json.dump(results, f, indent=2)

    print(f"\n{'=' * 78}")
    print(f"{'Drawing':<45} {'Verdict':<18} {'Mismatch':<10} {'Crit':<5}")
    print(f"{'-' * 78}")
    for r in results:
        print(f"{r['drawing']:<45} {r.get('overall_match', '?'):<18} "
              f"{str(r.get('n_mismatches', '-')):<10} {str(r.get('n_critical', '-')):<5}")

    good = sum(1 for r in results if r.get("overall_match") == "good_match")
    minor = sum(1 for r in results if r.get("overall_match") == "minor_mismatch")
    major = sum(1 for r in results if r.get("overall_match") == "major_mismatch")
    err = sum(1 for r in results if r.get("overall_match") == "ERROR")
    total_time = sum(r.get("seconds", 0) for r in results)

    print(f"{'-' * 78}")
    print(f"good_match: {good}   minor_mismatch: {minor}   major_mismatch: {major}   errors: {err}")
    print(f"Total time: {total_time:.0f}s ({total_time/60:.1f} min)")
    print(f"Reports in: {out_dir}/")


if __name__ == "__main__":
    run_batch()
