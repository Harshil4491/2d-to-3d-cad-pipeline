# 2D-to-3D CAD Reconstruction Pipeline (PoC)

AI-assisted conversion of 2D engineering drawings (flanges) into parametric 3D CAD
models, with automated validation and engineer review. Runs fully local.

## Pipeline

| Step | Script | What it does |
|---|---|---|
| 1 | batch_extract.py | Reads each drawing PDF with a local VLM, outputs structured JSON |
| 2 | generate_cad.py | Builds parametric 3D models from the JSON, exports STEP |
| 3 | render_models.py | Renders multi-view PNGs from each STEP file |
| 4 | validate_geometry.py | Deterministic geometry checks: model vs extracted data |
| 5 | compare_vlm.py | AI visual comparison: rendered model vs original drawing |
| 6 | build_html_review.py | Static HTML review sheet for engineers |
| 6b | server.py + workbench.html | Interactive review workbench (FastAPI + React) |

## Requirements

- NVIDIA DGX Spark (GB10 / aarch64) or equivalent CUDA 13 machine
- Python 3.12 venv: torch (cu130), build123d, opencv-python-headless,
  pdf2image, matplotlib, fastapi, uvicorn, openai
- Local vLLM serving Qwen3.8-27B (see docker command in project notes)

## Dataset

raw_dataset/ is not committed. The PoC used 20 ASME B16.5 flange drawings
from texasflange.com - check their terms before redistributing.

## Scope and known limitations

- One part family (flanges) only
- Geometry built: base disk, bore, bolt holes, hub/neck, raised face
- NOT modeled: RTJ grooves, threads, chamfers, fillets
- GD&T interpretation deliberately out of scope
- Both validation layers produce occasional false positives - human review is
  required, not optional
