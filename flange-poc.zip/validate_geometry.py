import json
import os
import glob
from build123d import import_step

TOL = 0.02


def rel_diff(a, b):
    if a is None or b is None:
        return None
    if max(abs(a), abs(b)) == 0:
        return 0.0
    return abs(a - b) / max(abs(a), abs(b))


def count_cylindrical_holes(part):
    radii = {}
    for face in part.faces():
        try:
            surf_type = str(face.geom_type).lower()
        except Exception:
            continue
        if "cylinder" in surf_type:
            try:
                r = face.radius
            except Exception:
                continue
            key = round(r, 4)
            radii[key] = radii.get(key, 0) + 1
    return radii


def validate(step_path, extraction, checks):
    part = import_step(step_path)
    result = extraction["result"]
    bf = result["base_feature"]
    features = result.get("features", [])

    bbox = part.bounding_box()
    model_od = max(bbox.size.X, bbox.size.Y)
    model_height = bbox.size.Z
    model_volume = part.volume

    stated_od = bf.get("outer_diameter")
    d = rel_diff(model_od, stated_od)
    checks.append({
        "check": "outer_diameter", "stated": stated_od, "measured": round(model_od, 4),
        "pass": d is not None and d <= TOL,
        "detail": f"rel diff {d:.3%}" if d is not None else "missing value",
    })

    stated_height = bf.get("total_height") or bf.get("overall_thickness")
    rf_h = bf.get("raised_face_height") or 0
    _thk = bf.get("overall_thickness") or 0
    _tot = bf.get("total_height") or _thk
    # the raised face and any hub both rise from the same flange face, so they
    # overlap rather than stack: the model height is whichever reaches higher.
    expected_height = max(_tot, _thk + rf_h)
    d = rel_diff(model_height, expected_height)
    checks.append({
        "check": "total_height", "stated": round(expected_height, 4), "measured": round(model_height, 4),
        "pass": d is not None and d <= TOL,
        "detail": f"rel diff {d:.3%}" if d is not None else "missing value",
    })

    stated_bore = bf.get("bore_diameter")
    radii = count_cylindrical_holes(part)
    if stated_bore:
        target_r = stated_bore / 2
        bore_found = any(abs(r - target_r) / target_r <= TOL for r in radii)
        checks.append({
            "check": "bore_present", "stated": stated_bore,
            "measured": "found" if bore_found else "NOT FOUND", "pass": bore_found,
            "detail": f"looked for radius ~{target_r:.4f} among {sorted(radii.keys())}",
        })
    else:
        checks.append({
            "check": "bore_absent", "stated": None, "measured": "n/a", "pass": True,
            "detail": "no bore expected (blind flange)",
        })

    bolt_feature = next((f for f in features if f.get("feature_type") == "bolt_holes"), None)
    stated_bolt_count = bolt_feature.get("quantity") if bolt_feature else None
    stated_bolt_d = bolt_feature.get("value") if bolt_feature else None

    if stated_bolt_count and stated_bolt_d:
        target_r = stated_bolt_d / 2
        matched = 0
        for r, count in radii.items():
            if abs(r - target_r) / target_r <= TOL:
                matched += count
        checks.append({
            "check": "bolt_hole_count", "stated": stated_bolt_count, "measured": matched,
            "pass": matched == stated_bolt_count,
            "detail": f"looked for radius ~{target_r:.4f}; found {matched} cylindrical faces",
        })
    elif result.get("bolt_circle_diameter"):
        checks.append({
            "check": "bolt_hole_count",
            "stated": "bolt circle stated but no bolt_holes feature",
            "measured": 0, "pass": False,
            "detail": "extraction gap - bolt circle present but hole size/count missing",
        })

    thickness = bf.get("overall_thickness")
    total_h = bf.get("total_height") or thickness
    hub_feature = next((f for f in features if f.get("feature_type") == "hub"), None)
    if total_h and thickness and total_h > thickness * (1 + TOL):
        checks.append({
            "check": "hub_expected",
            "stated": f"total_height {total_h} > thickness {thickness}",
            "measured": "hub feature present" if hub_feature else "NO HUB FEATURE",
            "pass": hub_feature is not None,
            "detail": "part is taller than its disk, so a hub/neck should be defined",
        })

    try:
        n_solids = len(part.solids())
    except Exception:
        n_solids = None
    checks.append({
        "check": "single_solid", "stated": 1, "measured": n_solids,
        "pass": n_solids == 1,
        "detail": "more than one solid means disconnected/floating geometry",
    })

    return {
        "model_volume": round(model_volume, 4),
        "model_od": round(model_od, 4),
        "model_height": round(model_height, 4),
        "radii_found": {str(k): v for k, v in sorted(radii.items())},
    }


def run_batch(cad_dir="cad_output", extracted_dir="extracted", out_dir="validation"):
    os.makedirs(out_dir, exist_ok=True)
    step_files = sorted(glob.glob(os.path.join(cad_dir, "*.step")))

    all_results = []
    print(f"Validating {len(step_files)} models against their extractions...\n")

    for step_path in step_files:
        name = os.path.splitext(os.path.basename(step_path))[0]
        json_path = os.path.join(extracted_dir, f"{name}.json")

        if not os.path.exists(json_path):
            print(f"[SKIP] {name} - no extraction JSON")
            continue

        with open(json_path) as f:
            extraction = json.load(f)

        checks = []
        try:
            measured = validate(step_path, extraction, checks)
        except Exception as e:
            print(f"[ERROR] {name}: {e}")
            all_results.append({"drawing": name, "status": "ERROR", "error": str(e)})
            continue

        n_pass = sum(1 for c in checks if c["pass"])
        n_total = len(checks)
        failed = [c for c in checks if not c["pass"]]
        status = "PASS" if not failed else "FAIL"

        print(f"[{status}] {name}  ({n_pass}/{n_total} checks passed)")
        for c in failed:
            print(f"     x {c['check']}: stated={c['stated']} measured={c['measured']}")
            print(f"       {c['detail']}")

        all_results.append({
            "drawing": name, "status": status,
            "checks_passed": n_pass, "checks_total": n_total,
            "measured": measured, "checks": checks,
        })

    with open(os.path.join(out_dir, "_validation_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2)

    n_pass = sum(1 for r in all_results if r.get("status") == "PASS")
    n_fail = sum(1 for r in all_results if r.get("status") == "FAIL")
    n_err = sum(1 for r in all_results if r.get("status") == "ERROR")

    print(f"\n{'=' * 70}")
    print(f"PASS: {n_pass}   FAIL: {n_fail}   ERROR: {n_err}   (of {len(all_results)})")
    print(f"Full report: {out_dir}/_validation_summary.json")

    fail_counts = {}
    for r in all_results:
        for c in r.get("checks", []):
            if not c["pass"]:
                fail_counts[c["check"]] = fail_counts.get(c["check"], 0) + 1
    if fail_counts:
        print(f"\nMost common failures:")
        for check, count in sorted(fail_counts.items(), key=lambda x: -x[1]):
            print(f"  {check}: {count}")


if __name__ == "__main__":
    run_batch()
