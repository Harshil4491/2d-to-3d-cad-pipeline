import base64
import json
import re
from pdf2image import convert_from_path
from openai import OpenAI
import io

client = OpenAI(base_url='http://localhost:8000/v1', api_key='EMPTY')

FEATURE_SCHEMA = {
    "type": "object",
    "properties": {
        "part_family": {"type": "string"},
        "part_type": {"type": "string"},
        "nominal_size": {"type": "string"},
        "pressure_class": {"type": "string"},
        "base_feature": {
            "type": "object",
            "properties": {
                "shape": {"type": "string", "enum": ["disk", "ring", "other"]},
                "outer_diameter": {"type": "number"},
                "overall_thickness": {"type": "number", "description": "thickness of the flange body/disk only, excluding any hub or neck"},
                "total_height": {"type": ["number", "null"], "description": "full height including hub/neck/extension, if present; null if the part has no hub/neck (i.e. equals overall_thickness)"},
                "bore_diameter": {"type": ["number", "null"]}
            },
            "required": ["shape", "outer_diameter", "overall_thickness", "total_height", "bore_diameter"]
        },
        "features": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "feature_type": {
                        "type": "string",
                        "enum": ["bolt_holes", "hub", "raised_face", "groove", "thread",
                                 "chamfer", "fillet", "counterbore", "other"]
                    },
                    "quantity": {"type": "integer"},
                    "value": {"type": "number"},
                    "unit": {"type": "string", "enum": ["in", "mm", "deg"]},
                    "description": {"type": "string"},
                    "confidence": {"type": "string", "enum": ["high", "medium", "low"]}
                },
                "required": ["feature_type", "value", "unit", "description", "confidence"]
            }
        },
        "bolt_circle_diameter": {"type": ["number", "null"]},
        "needs_review": {"type": "boolean"},
        "review_reason": {"type": "string"}
    },
    "required": ["part_family", "part_type", "nominal_size", "base_feature",
                 "features", "needs_review", "review_reason"]
}

REQUIRED_TOP_LEVEL = FEATURE_SCHEMA["required"]
REQUIRED_BASE_FEATURE = FEATURE_SCHEMA["properties"]["base_feature"]["required"]

PROMPT = """You are a mechanical engineering drawing interpretation agent. Analyze this flange drawing and extract a structured feature tree matching the exact JSON schema you were given.

The schema has these EXACT top-level fields, and no others:
- part_family (string)
- part_type (string, from title block)
- nominal_size (string, from title block)
- pressure_class (string)
- base_feature (object): shape ["disk","ring","other"], outer_diameter (number), overall_thickness (number, the flange body/disk thickness ONLY - do not include hub or neck height), total_height (number or null - the FULL height of the part including any hub, neck, or extension body; set to null if the part is flat with no hub/neck, in which case it equals overall_thickness), bore_diameter (number or null)
- features (array of objects): feature_type ["bolt_holes","hub","raised_face","groove","thread","chamfer","fillet","counterbore","other"], quantity (integer), value (number), unit ["in","mm","deg" - use deg only for angles like chamfer/taper angles], description (string), confidence ["high","medium","low"]
- bolt_circle_diameter (number or null)
- needs_review (boolean)
- review_reason (string, empty string if needs_review is false)

Rules:
- Read every dimension precisely as shown; do not round or estimate.
- Use the EXACT field names above - do not invent your own field names or add extra top-level fields.
- If a bore/hole does not exist on this part (e.g. a blind flange), set bore_diameter to null.
- Set needs_review to true ONLY for what you can directly observe as unclear, illegible, ambiguous, or missing on the drawing itself.
- CRITICAL: Do NOT compare dimensions against external standards (e.g. ASME B16.5) or invent reference values to justify a discrepancy. You do not have access to a standards lookup table. Only report what is visibly on the drawing. Never state a value "should be" something different from what is shown.
- IMPORTANT: overall_thickness is ONLY the flat flange disk/body thickness. If the part has a hub, neck, or any extension (weld-neck, long-weld-neck, extension body, etc.), put the full end-to-end height in total_height as a SEPARATE value - do not merge the two into one number.
- List EVERY distinct feature you can see, including all threaded holes, jack bolt provisions, and secondary ports - do not stop after the primary bolt pattern and groove.
- IMPORTANT: a groove reference like "GROOVE # R28" is a standard groove DESIGNATION/ID, not a dimension - do not put the number after "R" into the value field. If you cannot read an actual groove diameter or width measurement on the drawing, set confidence to "low" and note this in description.
- Output ONLY the raw JSON object. No markdown code fences, no explanation before or after."""


def strip_fences(text):
    text = text.strip()
    text = re.sub(r'^```(?:json)?\s*', '', text)
    text = re.sub(r'\s*```$', '', text)
    return text.strip()


COMPLEXITY_REVIEW_FEATURE_TYPES = {"groove", "thread", "counterbore"}
COMPLEXITY_REVIEW_FEATURE_COUNT = 4


def apply_complexity_heuristic(parsed):
    """Model self-reported confidence isn't reliable on dense drawings (observed:
    two complex flanges both under-flagged themselves). Force needs_review=True
    when the drawing has enough features that a missed detail is likely, so a
    human always double-checks these regardless of what the model claims."""
    features = parsed.get("features", [])
    reasons = []

    if len(features) > COMPLEXITY_REVIEW_FEATURE_COUNT:
        reasons.append(
            f"{len(features)} features detected (>{COMPLEXITY_REVIEW_FEATURE_COUNT}) - "
            f"complex drawings are more likely to have missed or misread features"
        )

    present_risky_types = {f.get("feature_type") for f in features} & COMPLEXITY_REVIEW_FEATURE_TYPES
    if present_risky_types:
        reasons.append(
            f"Contains feature type(s) prone to misreads: {', '.join(sorted(present_risky_types))}"
        )

    if reasons and not parsed.get("needs_review", False):
        parsed["needs_review"] = True
        heuristic_note = "Auto-flagged by complexity heuristic: " + "; ".join(reasons)
        existing = parsed.get("review_reason", "")
        parsed["review_reason"] = (existing + " | " + heuristic_note) if existing else heuristic_note

    return parsed


def validate_schema(parsed):
    """Returns a list of problems; empty list means it matches our schema."""
    problems = []
    for field in REQUIRED_TOP_LEVEL:
        if field not in parsed:
            problems.append(f"Missing top-level field: {field}")
    if "base_feature" in parsed and isinstance(parsed["base_feature"], dict):
        for field in REQUIRED_BASE_FEATURE:
            if field not in parsed["base_feature"]:
                problems.append(f"Missing base_feature field: {field}")
    elif "base_feature" in parsed:
        problems.append("base_feature is not an object")
    if "features" in parsed and not isinstance(parsed["features"], list):
        problems.append("features is not an array")
    return problems


def extract_features(pdf_path, retry_on_schema_mismatch=True):
    pages = convert_from_path(pdf_path, dpi=300)
    buf = io.BytesIO()
    pages[0].save(buf, format='PNG')
    img_b64 = base64.b64encode(buf.getvalue()).decode()

    messages = [{
        'role': 'user',
        'content': [
            {'type': 'text', 'text': PROMPT},
            {'type': 'image_url', 'image_url': {'url': f'data:image/png;base64,{img_b64}'}}
        ]
    }]

    response = client.chat.completions.create(
        model='Qwen/Qwen3.8-27B',
        messages=messages,
        max_tokens=2048,
        temperature=0,
        extra_body={
            'chat_template_kwargs': {'enable_thinking': False},
            'guided_json': FEATURE_SCHEMA,
        },
    )
    raw = response.choices[0].message.content
    cleaned = strip_fences(raw)

    try:
        parsed = json.loads(cleaned)
    except json.JSONDecodeError as e:
        return {"error": f"JSON parse failed: {e}", "raw": raw}

    problems = validate_schema(parsed)

    if problems and retry_on_schema_mismatch:
        correction = (f"Your previous output did not match the required schema. "
                      f"Problems: {'; '.join(problems)}. "
                      f"Re-extract the same drawing and output ONLY valid JSON with "
                      f"exactly the required field names.")
        messages.append({'role': 'assistant', 'content': raw})
        messages.append({'role': 'user', 'content': correction})

        response = client.chat.completions.create(
            model='Qwen/Qwen3.8-27B',
            messages=messages,
            max_tokens=2048,
            extra_body={
                'chat_template_kwargs': {'enable_thinking': False},
                'guided_json': FEATURE_SCHEMA,
            },
        )
        raw2 = response.choices[0].message.content
        cleaned2 = strip_fences(raw2)
        try:
            parsed2 = json.loads(cleaned2)
            problems2 = validate_schema(parsed2)
            parsed2 = apply_complexity_heuristic(parsed2)
            if not problems2:
                return {"result": parsed2, "schema_valid": True, "retried": True}
            else:
                return {"result": parsed2, "schema_valid": False,
                        "problems": problems2, "retried": True}
        except json.JSONDecodeError as e:
            return {"error": f"JSON parse failed on retry: {e}", "raw": raw2}

    parsed = apply_complexity_heuristic(parsed)
    return {"result": parsed, "schema_valid": not problems,
            "problems": problems, "retried": False}


if __name__ == "__main__":
    test_drawings = [
        'raw_dataset/0.5-150-BLIND-RF-FLANGE.pdf',
        'raw_dataset/0.5-300-WELD-NECK-FF-160-FLANGE.pdf',
        'raw_dataset/2.5-2500-RTJ-WELD-NECK-80-ORIF-FLANGE.pdf',
    ]

    for path in test_drawings:
        print(f"\n{'=' * 60}\n{path}\n{'=' * 60}")
        outcome = extract_features(path)
        print(json.dumps(outcome, indent=2))
