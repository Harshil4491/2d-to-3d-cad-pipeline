import json
import csv
import glob
import os

def summarize_features(features):
    parts = []
    for f in features:
        qty = f.get("quantity")
        qty_str = f"{qty}x " if qty and qty > 1 else ""
        parts.append(f"{qty_str}{f.get('feature_type')}: {f.get('value')}{f.get('unit')} "
                     f"[{f.get('confidence')}] - {f.get('description')}")
    return " | ".join(parts)


def build_review_sheet(extracted_dir="extracted", out_csv="sme_review_sheet.csv"):
    json_files = sorted(glob.glob(os.path.join(extracted_dir, "*.json")))
    json_files = [f for f in json_files if not f.endswith("_summary.json")]

    rows = []
    for path in json_files:
        with open(path) as f:
            data = json.load(f)

        name = os.path.splitext(os.path.basename(path))[0]

        if "error" in data:
            rows.append({
                "drawing": name,
                "part_type": "ERROR",
                "nominal_size": "",
                "outer_diameter": "",
                "overall_thickness": "",
                "total_height": "",
                "bore_diameter": "",
                "bolt_circle_diameter": "",
                "features_summary": data.get("error", ""),
                "ai_needs_review": "",
                "ai_review_reason": "",
                "sme_agree": "",
                "sme_corrections": "",
                "sme_notes": "",
            })
            continue

        result = data["result"]
        bf = result.get("base_feature", {})

        rows.append({
            "drawing": name,
            "part_type": result.get("part_type", ""),
            "nominal_size": result.get("nominal_size", ""),
            "outer_diameter": bf.get("outer_diameter", ""),
            "overall_thickness": bf.get("overall_thickness", ""),
            "total_height": bf.get("total_height", ""),
            "bore_diameter": bf.get("bore_diameter", ""),
            "bolt_circle_diameter": result.get("bolt_circle_diameter", ""),
            "features_summary": summarize_features(result.get("features", [])),
            "ai_needs_review": result.get("needs_review", ""),
            "ai_review_reason": result.get("review_reason", ""),
            "sme_agree": "",
            "sme_corrections": "",
            "sme_notes": "",
        })

    fieldnames = [
        "drawing", "part_type", "nominal_size",
        "outer_diameter", "overall_thickness", "total_height", "bore_diameter",
        "bolt_circle_diameter", "features_summary",
        "ai_needs_review", "ai_review_reason",
        "sme_agree", "sme_corrections", "sme_notes",
    ]

    with open(out_csv, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    print(f"Wrote {len(rows)} rows to {out_csv}")
    n_flagged = sum(1 for r in rows if r["ai_needs_review"] is True)
    print(f"Drawings pre-flagged for review: {n_flagged}/{len(rows)}")
    print(f"\nOpen {out_csv} in Excel/Google Sheets and have the SME fill in:")
    print("  - sme_agree: Yes / No / Partial")
    print("  - sme_corrections: what's wrong, if anything")
    print("  - sme_notes: any free-text comments")


if __name__ == "__main__":
    build_review_sheet()
