import json, os, glob, base64, io
from pdf2image import convert_from_path
from PIL import Image

OUT_HTML = "review_sheet.html"

def img_b64(pil_img, max_dim=900, quality=72):
    w, h = pil_img.size
    if max(w, h) > max_dim:
        s = max_dim / max(w, h)
        pil_img = pil_img.resize((int(w*s), int(h*s)), Image.LANCZOS)
    buf = io.BytesIO()
    pil_img.convert("RGB").save(buf, format="JPEG", quality=quality, optimize=True)
    return base64.b64encode(buf.getvalue()).decode()

def load_json(path, default=None):
    if not os.path.exists(path): return default
    with open(path) as f: return json.load(f)

def fmt_val(v):
    return '<span class="null">null</span>' if v is None else str(v)

CSS = """
*{box-sizing:border-box}
body{font-family:-apple-system,Segoe UI,Roboto,sans-serif;margin:0;background:#f4f5f7;color:#1c1e21;line-height:1.45}
header{background:#1c2b3a;color:#fff;padding:22px 28px}
header h1{margin:0 0 4px;font-size:20px}
header p{margin:0;opacity:.75;font-size:13px}
.summary{display:flex;gap:26px;margin-top:12px;font-size:13px}
.summary b{font-size:18px;display:block}
nav{background:#2a3d50;padding:8px 28px;font-size:12px}
nav a{color:#cbd6e2;text-decoration:none;padding:2px 6px;display:inline-block}
main{padding:24px 28px;max-width:1500px;margin:0 auto}
.card{background:#fff;border-radius:8px;margin-bottom:26px;padding:20px;box-shadow:0 1px 3px rgba(0,0,0,.12);border-left:5px solid #ccc}
.card.flagged{border-left-color:#d9822b}
.card.clean{border-left-color:#3f9142}
.cardhead{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:14px}
.cardhead h2{margin:2px 0 0;font-size:16px;font-family:ui-monospace,monospace}
.idx{font-size:11px;color:#888}
.banner{font-size:11px;font-weight:700;padding:5px 11px;border-radius:12px}
.banner.flagged{background:#fdf0e2;color:#a55b12}
.banner.clean{background:#e8f5e9;color:#2b6a2e}
.images{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:18px}
figure{margin:0}
figcaption{font-size:11px;text-transform:uppercase;color:#666;margin-bottom:5px}
.images img{width:100%;border:1px solid #dde1e6;border-radius:5px}
.panels{display:grid;grid-template-columns:1fr 1fr;gap:22px}
.panel h3{font-size:13px;margin:0 0 8px;text-transform:uppercase;color:#444}
.panel h3:not(:first-child){margin-top:18px}
table{width:100%;border-collapse:collapse;font-size:12.5px;margin-bottom:12px}
.kv td{padding:4px 6px;border-bottom:1px solid #eee}
.kv td:first-child{color:#666;width:44%}
.feat th{text-align:left;background:#f0f2f5;padding:5px 6px;font-size:11px;color:#555}
.feat td{padding:4px 6px;border-bottom:1px solid #eee;vertical-align:top}
ul{margin:0 0 10px;padding-left:18px;font-size:12.5px}
li{margin-bottom:6px}
li.ok{color:#2b6a2e;list-style:none;margin-left:-18px}
.detail{color:#777;font-size:11.5px}
.null{color:#aaa;font-style:italic}
code{background:#f0f2f5;padding:1px 4px;border-radius:3px;font-size:11.5px}
.tag{font-size:10px;padding:2px 7px;border-radius:9px;margin-left:6px}
.tag.good{background:#e8f5e9;color:#2b6a2e}
.tag.bad{background:#fdecea;color:#a52714}
.aiflag{font-size:12px;background:#f7f8fa;padding:8px 10px;border-radius:5px;margin:0}
.signoff{margin-top:20px;padding:14px;background:#f7f8fa;border-radius:6px;border:1px dashed #c6ccd4}
.signoff label{display:block;margin-bottom:6px;font-size:13px}
.notes{font-size:12px;color:#666;margin:10px 0 0}
@media print{.card{page-break-inside:avoid;box-shadow:none;border:1px solid #ccc}}
"""

def build():
    pdfs = sorted(glob.glob("raw_dataset/*.pdf"))
    validation = {r["drawing"]: r for r in (load_json("validation/_validation_summary.json") or [])}
    cards = []
    stats = {"both_clean":0,"geom_fail":0,"vlm_fail":0,"either_fail":0}

    for idx, pdf_path in enumerate(pdfs, 1):
        name = os.path.splitext(os.path.basename(pdf_path))[0]
        extraction = load_json(f"extracted/{name}.json")
        comparison = load_json(f"comparison/{name}.json")
        val = validation.get(name)

        try:
            draw_b64 = img_b64(convert_from_path(pdf_path, dpi=150)[0])
        except Exception:
            draw_b64 = None
        rp = f"renders/{name}.png"
        render_b64 = img_b64(Image.open(rp)) if os.path.exists(rp) else None

        geom_status = val["status"] if val else "N/A"
        geom_failed = [c for c in (val or {}).get("checks", []) if not c["pass"]]
        vlm_status = (comparison or {}).get("overall_match", "N/A")
        vlm_mm = (comparison or {}).get("mismatches", []) or []

        geom_bad = geom_status == "FAIL"
        vlm_bad = vlm_status in ("major_mismatch","minor_mismatch")
        if geom_bad: stats["geom_fail"] += 1
        if vlm_bad: stats["vlm_fail"] += 1
        if geom_bad or vlm_bad: stats["either_fail"] += 1
        else: stats["both_clean"] += 1

        fc = "flagged" if (geom_bad or vlm_bad) else "clean"
        banner = "NEEDS REVIEW" if (geom_bad or vlm_bad) else "BOTH CHECKS PASSED"

        r = (extraction or {}).get("result", {})
        bf = r.get("base_feature", {}) or {}
        feats = r.get("features", []) or []

        feat_rows = "".join(
            f"<tr><td>{f.get('feature_type','')}</td><td>{fmt_val(f.get('quantity'))}</td>"
            f"<td>{fmt_val(f.get('value'))} {f.get('unit','')}</td>"
            f"<td>{f.get('confidence','')}</td><td>{f.get('description','')}</td></tr>"
            for f in feats) or "<tr><td colspan='5' class='null'>none</td></tr>"

        geom_rows = "".join(
            f"<li><b>{c['check']}</b>: stated <code>{c['stated']}</code>, measured <code>{c['measured']}</code>"
            f"<br><span class='detail'>{c['detail']}</span></li>" for c in geom_failed
        ) or "<li class='ok'>All geometry checks passed</li>"

        vlm_rows = "".join(
            f"<li><b>[{m.get('severity','?')}]</b> {m.get('description','')}</li>" for m in vlm_mm
        ) or "<li class='ok'>No visual mismatches reported</li>"

        ai_reason = r.get("review_reason","")
        dimg = f'<img src="data:image/jpeg;base64,{draw_b64}">' if draw_b64 else '<p class="null">n/a</p>'
        rimg = f'<img src="data:image/jpeg;base64,{render_b64}">' if render_b64 else '<p class="null">n/a</p>'

        cards.append(f"""<section class="card {fc}" id="d{idx}">
<div class="cardhead"><div><span class="idx">{idx}/{len(pdfs)}</span><h2>{name}</h2></div>
<span class="banner {fc}">{banner}</span></div>
<div class="images">
<figure><figcaption>Original drawing</figcaption>{dimg}</figure>
<figure><figcaption>Generated 3D model</figcaption>{rimg}</figure></div>
<div class="panels">
<div class="panel"><h3>Extracted data</h3>
<table class="kv">
<tr><td>part type</td><td>{fmt_val(r.get('part_type'))}</td></tr>
<tr><td>nominal size</td><td>{fmt_val(r.get('nominal_size'))}</td></tr>
<tr><td>outer diameter</td><td>{fmt_val(bf.get('outer_diameter'))}</td></tr>
<tr><td>overall thickness</td><td>{fmt_val(bf.get('overall_thickness'))}</td></tr>
<tr><td>total height</td><td>{fmt_val(bf.get('total_height'))}</td></tr>
<tr><td>raised face height</td><td>{fmt_val(bf.get('raised_face_height'))}</td></tr>
<tr><td>bore diameter</td><td>{fmt_val(bf.get('bore_diameter'))}</td></tr>
<tr><td>bolt circle</td><td>{fmt_val(r.get('bolt_circle_diameter'))}</td></tr>
</table>
<table class="feat"><tr><th>feature</th><th>qty</th><th>value</th><th>conf</th><th>description</th></tr>
{feat_rows}</table>
<p class="aiflag"><b>AI self-flag:</b> {fmt_val(r.get('needs_review'))}
{('<br><span class="detail">'+ai_reason+'</span>') if ai_reason else ''}</p></div>
<div class="panel">
<h3>Geometry check <span class="tag {'bad' if geom_bad else 'good'}">{geom_status}</span></h3>
<ul>{geom_rows}</ul>
<h3>Visual comparison <span class="tag {'bad' if vlm_bad else 'good'}">{vlm_status}</span></h3>
<ul>{vlm_rows}</ul>
<div class="signoff"><h3>Engineer sign-off</h3>
<label><input type="checkbox"> Approve as-is</label>
<label><input type="checkbox"> Approve with corrections</label>
<label><input type="checkbox"> Reject / needs rework</label>
<p class="notes">Notes: ___________________________________</p></div>
</div></div></section>""")

    nav = "".join(f'<a href="#d{i}">{i}</a>' for i in range(1, len(pdfs)+1))
    html = ('<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">'
        '<title>Flange PoC - Engineer Review Sheet</title><style>' + CSS + '</style></head><body>'
        '<header><h1>AI-Assisted 2D&rarr;3D CAD Reconstruction &mdash; Engineer Review Sheet</h1>'
        f'<p>Flange part family &middot; {len(pdfs)} drawings &middot; generated from local pipeline</p>'
        '<div class="summary">'
        f'<div><b>{stats["both_clean"]}</b>both checks passed</div>'
        f'<div><b>{stats["either_fail"]}</b>flagged for review</div>'
        f'<div><b>{stats["geom_fail"]}</b>geometry check failed</div>'
        f'<div><b>{stats["vlm_fail"]}</b>visual mismatch</div>'
        '</div></header>'
        f'<nav>Jump to: {nav}</nav><main>' + "".join(cards) + '</main></body></html>')

    with open(OUT_HTML, "w") as f:
        f.write(html)
    print(f"Wrote {OUT_HTML} ({os.path.getsize(OUT_HTML)/1024/1024:.1f} MB)")
    print(f"  both checks passed : {stats['both_clean']}")
    print(f"  flagged for review : {stats['either_fail']}")

if __name__ == "__main__":
    build()
