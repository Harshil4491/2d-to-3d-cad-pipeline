import json, os, glob, io, subprocess, datetime
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse, StreamingResponse, FileResponse
from pydantic import BaseModel
from pdf2image import convert_from_path
from PIL import Image

ROOT = os.path.dirname(os.path.abspath(__file__))
AUDIT = os.path.join(ROOT, "review_audit.json")

app = FastAPI(title="Flange PoC Review Workbench")


def load(path, default=None):
    if not os.path.exists(path):
        return default
    try:
        with open(path) as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return default


def drawing_names():
    return [os.path.splitext(os.path.basename(p))[0]
            for p in sorted(glob.glob(os.path.join(ROOT, "raw_dataset", "*.pdf")))]


def audit_log():
    return load(AUDIT, {}) or {}


def validation_map():
    rows = load(os.path.join(ROOT, "validation", "_validation_summary.json"), []) or []
    return {r["drawing"]: r for r in rows}


def summarize(name, val, comp, audit):
    geom = val.get("status") if val else "N/A"
    vlm = (comp or {}).get("overall_match", "N/A")
    geom_bad = geom == "FAIL"
    vlm_bad = vlm in ("major_mismatch", "minor_mismatch")
    rec = audit.get(name)
    return {
        "name": name,
        "geometry_status": geom,
        "visual_status": vlm,
        "flagged": geom_bad or vlm_bad,
        "reviewed": bool(rec),
        "decision": rec.get("decision") if rec else None,
    }


@app.get("/api/drawings")
def list_drawings():
    vmap = validation_map()
    audit = audit_log()
    out = []
    for name in drawing_names():
        comp = load(os.path.join(ROOT, "comparison", f"{name}.json"))
        out.append(summarize(name, vmap.get(name), comp, audit))
    return {"drawings": out, "total": len(out)}


@app.get("/api/drawings/{name}")
def get_drawing(name: str):
    if name not in drawing_names():
        raise HTTPException(404, "unknown drawing")
    extraction = load(os.path.join(ROOT, "extracted", f"{name}.json"))
    comparison = load(os.path.join(ROOT, "comparison", f"{name}.json"))
    validation = validation_map().get(name)
    gen = load(os.path.join(ROOT, "cad_output", "_generation_summary.json"), []) or []
    gen_row = next((g for g in gen if g.get("drawing") == name), None)
    return {
        "name": name,
        "extraction": extraction,
        "validation": validation,
        "comparison": comparison,
        "generation": gen_row,
        "review": audit_log().get(name),
        "step_available": os.path.exists(os.path.join(ROOT, "cad_output", f"{name}.step")),
    }


@app.get("/api/image/drawing/{name}")
def drawing_image(name: str):
    pdf = os.path.join(ROOT, "raw_dataset", f"{name}.pdf")
    if not os.path.exists(pdf):
        raise HTTPException(404, "no pdf")
    img = convert_from_path(pdf, dpi=150)[0]
    buf = io.BytesIO()
    img.convert("RGB").save(buf, format="JPEG", quality=80)
    buf.seek(0)
    return StreamingResponse(buf, media_type="image/jpeg")


@app.get("/api/image/render/{name}")
def render_image(name: str):
    p = os.path.join(ROOT, "renders", f"{name}.png")
    if not os.path.exists(p):
        raise HTTPException(404, "no render")
    return FileResponse(p, media_type="image/png")


@app.get("/api/export/{name}")
def export_step(name: str):
    p = os.path.join(ROOT, "cad_output", f"{name}.step")
    if not os.path.exists(p):
        raise HTTPException(404, "no step file")
    return FileResponse(p, media_type="application/step", filename=f"{name}.step")


class ReviewIn(BaseModel):
    decision: str          # approved | approved_with_corrections | rejected
    notes: str = ""
    reviewer: str = ""
    corrections: dict = {}


@app.post("/api/review/{name}")
def submit_review(name: str, body: ReviewIn):
    if name not in drawing_names():
        raise HTTPException(404, "unknown drawing")
    if body.decision not in ("approved", "approved_with_corrections", "rejected"):
        raise HTTPException(400, "invalid decision")
    audit = audit_log()
    entry = {
        "decision": body.decision,
        "notes": body.notes,
        "reviewer": body.reviewer or "unknown",
        "corrections": body.corrections,
        "timestamp": datetime.datetime.now().isoformat(timespec="seconds"),
    }
    history = audit.get(name, {}).get("history", [])
    history.append(entry)
    entry["history"] = history
    audit[name] = entry
    tmp = AUDIT + ".tmp"
    with open(tmp, "w") as f:
        json.dump(audit, f, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, AUDIT)
    return {"ok": True, "review": entry}


class RegenIn(BaseModel):
    base_feature: dict = {}
    bolt_circle_diameter: float | None = None
    features: list = []


@app.post("/api/regenerate/{name}")
def regenerate(name: str, body: RegenIn):
    """Apply engineer corrections to the extraction JSON and rebuild the model."""
    path = os.path.join(ROOT, "extracted", f"{name}.json")
    data = load(path)
    if not data:
        raise HTTPException(404, "no extraction")

    backup = os.path.join(ROOT, "extracted", f"{name}.original.json")
    if not os.path.exists(backup):
        with open(backup, "w") as f:
            json.dump(data, f, indent=2)

    r = data["result"]
    if body.base_feature:
        r["base_feature"].update({k: v for k, v in body.base_feature.items() if v is not None})
    if body.bolt_circle_diameter is not None:
        r["bolt_circle_diameter"] = body.bolt_circle_diameter
    if body.features:
        r["features"] = body.features
    r["engineer_corrected"] = True

    with open(path, "w") as f:
        json.dump(data, f, indent=2)

    steps = []
    for script in ("generate_cad.py", "render_models.py", "validate_geometry.py"):
        p = subprocess.run(["python3", os.path.join(ROOT, script)],
                           cwd=ROOT, capture_output=True, text=True, timeout=900)
        steps.append({"script": script, "returncode": p.returncode,
                      "tail": p.stdout[-800:] if p.stdout else p.stderr[-800:]})
    return {"ok": True, "steps": steps}


@app.get("/", response_class=HTMLResponse)
def index():
    with open(os.path.join(ROOT, "workbench.html")) as f:
        return f.read()
