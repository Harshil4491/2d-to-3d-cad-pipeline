import os
import glob
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from build123d import import_step, Mesher


def step_to_triangles(step_path, tmp_stl="/tmp/_render_tmp.stl"):
    part = import_step(step_path)
    exporter = Mesher()
    exporter.add_shape(part, linear_deflection=0.02, angular_deflection=0.2)
    exporter.write(tmp_stl)

    with open(tmp_stl, "rb") as f:
        head = f.read(5)
        f.seek(0)
        if head == b"solid":
            text = f.read().decode("utf-8", errors="ignore")
            tris, cur = [], []
            for line in text.splitlines():
                line = line.strip()
                if line.startswith("vertex"):
                    cur.append([float(x) for x in line.split()[1:4]])
                    if len(cur) == 3:
                        tris.append(cur)
                        cur = []
            return np.array(tris)
        else:
            f.seek(80)
            n_tri = int.from_bytes(f.read(4), "little")
            tris = []
            for _ in range(n_tri):
                f.read(12)
                verts = []
                for _ in range(3):
                    verts.append(np.frombuffer(f.read(12), dtype="<f4"))
                f.read(2)
                tris.append(verts)
            return np.array(tris)


def render_part(step_path, out_png, title=""):
    tris = step_to_triangles(step_path)
    if len(tris) == 0:
        raise ValueError("no triangles produced")

    views = [(25, 45, "isometric"), (0, 0, "front"), (90, 0, "top")]
    fig = plt.figure(figsize=(13, 4.5))

    all_pts = tris.reshape(-1, 3)
    mins, maxs = all_pts.min(axis=0), all_pts.max(axis=0)
    center = (mins + maxs) / 2
    span = (maxs - mins).max() / 2 * 1.15

    for i, (elev, azim, label) in enumerate(views, 1):
        ax = fig.add_subplot(1, 3, i, projection="3d")
        coll = Poly3DCollection(tris, alpha=0.92)
        coll.set_facecolor((0.62, 0.68, 0.76))
        coll.set_edgecolor((0.30, 0.34, 0.40, 0.25))
        coll.set_linewidth(0.15)
        ax.add_collection3d(coll)

        ax.set_xlim(center[0] - span, center[0] + span)
        ax.set_ylim(center[1] - span, center[1] + span)
        ax.set_zlim(center[2] - span, center[2] + span)
        ax.view_init(elev=elev, azim=azim)
        ax.set_box_aspect((1, 1, 1))
        ax.set_title(label, fontsize=10)
        ax.set_axis_off()

    fig.suptitle(title, fontsize=11)
    fig.tight_layout()
    fig.savefig(out_png, dpi=95, bbox_inches="tight")
    plt.close(fig)


def run_batch(cad_dir="cad_output", out_dir="renders"):
    os.makedirs(out_dir, exist_ok=True)
    step_files = sorted(glob.glob(os.path.join(cad_dir, "*.step")))

    print(f"Rendering {len(step_files)} models...\n")
    results = []

    for path in step_files:
        name = os.path.splitext(os.path.basename(path))[0]
        out_png = os.path.join(out_dir, f"{name}.png")
        try:
            render_part(path, out_png, title=name)
            print(f"[OK]   {name}")
            results.append({"drawing": name, "status": "OK", "png": out_png})
        except Exception as e:
            print(f"[FAIL] {name}  {e}")
            results.append({"drawing": name, "status": "FAIL", "error": str(e)})

    with open(os.path.join(out_dir, "_render_summary.json"), "w") as f:
        json.dump(results, f, indent=2)

    n_ok = sum(1 for r in results if r["status"] == "OK")
    print(f"\nDone: {n_ok}/{len(results)} rendered")
    print(f"PNGs in: {out_dir}/")


if __name__ == "__main__":
    run_batch()
