import base64
import json
import re
import time
import os
import glob
from pdf2image import convert_from_path
from openai import OpenAI
import io

client = OpenAI(base_url='http://localhost:8000/v1', api_key='EMPTY')

FEATURE_SCHEMA = {
    "type": "object",
    "properties": {
        "part_family": {"type": "string"},
        "part_type": {"type": "string"},
        "nominal_size": {"type": "string"},
        "pressure_class": {"type": "string"},
        "base_feature": {
            "type": "object",
            "properties": {
                "shape": {"type": "string", "enum": ["disk", "ring", "other"]},
                "outer_diameter": {"type": "number"},
                "overall_thickness": {"type": "number"},
                "total_height": {"type": ["number", "null"]},
                "raised_face_height": {"type": ["number", "null"]},
                "raised_face_diameter": {"type": ["number", "null"]},
                "bore_diameter": {"type": ["number", "null"]}
            },
            "required": ["shape", "outer_diameter", "overall_thickness", "total_height", "raised_face_height", "raised_face_diameter", "bore_diameter"]
        },
        "features": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "feature_type": {
                        "type": "string",
                        "enum": ["bolt_holes", "hub", "raised_face", "groove", "thread",
                                 "chamfer", "fillet", "counterbore", "other"]
                    },
                    "quantity": {"type": "integer"},
                    "value": {"type": "number"},
                    "unit": {"type": "string", "enum": ["in", "mm", "deg"]},
                    "description": {"type": "string"},
                    "confidence": {"type": "string", "enum": ["high", "medium", "low"]}
                },
                "required": ["feature_type", "value", "unit", "description", "confidence"]
            }
        },
        "bolt_circle_diameter": {"type": ["number", "null"]},
        "needs_review": {"type": "boolean"},
        "review_reason": {"type": "string"}
    },
    "required": ["part_family", "part_type", "nominal_size", "base_feature",
                 "features", "needs_review", "review_reason"]
}

REQUIRED_TOP_LEVEL = FEATURE_SCHEMA["required"]
REQUIRED_BASE_FEATURE = FEATURE_SCHEMA["properties"]["base_feature"]["required"]

PROMPT = """You are a mechanical engineering drawing interpretation agent. Analyze this flange drawing and extract a structured feature tree matching the exact JSON schema you were given.

The schema has these EXACT top-level fields, and no others:
- part_family (string)
- part_type (string, from title block)
- nominal_size (string, from title block)
- pressure_class (string)
- base_feature (object): shape ["disk","ring","other"], outer_diameter (number), overall_thickness (number), total_height (number or null), raised_face_height (number or null), bore_diameter (number or null)

HEIGHT FIELD RULES - read carefully, these are the most commonly confused fields:
  * overall_thickness = the flat flange disk/body thickness only.
  * raised_face_height = the height of the thin raised sealing face (typically 0.06"-0.25"), if the part has one. This is a SEPARATE small step on the face - it is NOT part of total_height. If the part has no raised face, set this to null.
  * raised_face_diameter = the DIAMETER of that same raised sealing face, if the part has one (this is a separate dimension from raised_face_height - look for it near the raised face callout, often the smaller diameter shown in the section view close to the hub/bore). Set to null if there is no raised face.
  * total_height = overall_thickness PLUS the height of any HUB, NECK, or EXTENSION BODY only. Do NOT add raised face height, recess depth, or groove depth into total_height.
  * If the part is a flat disk or ring with no hub/neck (e.g. blind flange, studout ring, spec blind), total_height MUST equal overall_thickness exactly - even if the part has a raised face.
- features (array of objects): feature_type ["bolt_holes","hub","raised_face","groove","thread","chamfer","fillet","counterbore","other"], quantity (integer), value (number), unit ["in","mm","deg" - use deg only for angles like chamfer/taper angles], description (string), confidence ["high","medium","low"]
- bolt_circle_diameter (number or null)
- needs_review (boolean)
- review_reason (string, empty string if needs_review is false)

Rules:
- Read every dimension precisely as shown; do not round or estimate.
- Use the EXACT field names above - do not invent your own field names or add extra top-level fields.
- If a bore/hole does not exist on this part (e.g. a blind flange), set bore_diameter to null.
- Set needs_review to true ONLY for what you can directly observe as unclear, illegible, ambiguous, or missing on the drawing itself.
- CRITICAL: Do NOT compare dimensions against external standards (e.g. ASME B16.5) or invent reference values to justify a discrepancy. You do not have access to a standards lookup table. Only report what is visibly on the drawing. Never state a value "should be" something different from what is shown.
- IMPORTANT: overall_thickness is ONLY the flat flange disk/body thickness. If the part has a hub, neck, or any extension (weld-neck, long-weld-neck, extension body, etc.), put the full end-to-end height in total_height as a SEPARATE value - do not merge the two into one number.
- List EVERY distinct feature you can see, including all threaded holes, jack bolt provisions, and secondary ports - do not stop after the primary bolt pattern and groove.
- CRITICAL - HUB/NECK RULE: if the part has ANY raised cylindrical section, hub, neck, boss, or extension body rising above the flat flange face (common on weld-neck, long-weld-neck, socket-weld, slip-on, threaded, lap-joint, and extension-body flanges), you MUST include it as a feature with feature_type exactly "hub" - never "other". Its "value" must be the hub OUTER DIAMETER in inches (not its height, not the bore). The hub outer diameter must always be smaller than the flange outer_diameter and larger than the bore_diameter.
- CONSISTENCY CHECK: if you set total_height greater than overall_thickness, that means the part is not flat - so you MUST also include a corresponding "hub" feature explaining what makes it taller. total_height > overall_thickness with no hub feature is an error.
- IMPORTANT: a groove reference like "GROOVE # R28" is a standard groove DESIGNATION/ID, not a dimension - do not put the number after "R" into the value field. If you cannot read an actual groove diameter or width measurement on the drawing, set confidence to "low" and note this in description.
- IMPORTANT: check for internal consistency. For example, a flange whose title block/type says "FF" (flat face) should NOT have a raised_face feature; a part type containing "FF" and a raised_face feature in the same output is a contradiction - if you notice this, set needs_review to true and explain the conflict in review_reason rather than silently including both.
- Output ONLY the raw JSON object. No markdown code fences, no explanation before or after."""


def strip_fences(text):
    text = text.strip()
    text = re.sub(r'^```(?:json)?\s*', '', text)
    text = re.sub(r'\s*```$', '', text)
    return text.strip()


COMPLEXITY_REVIEW_FEATURE_TYPES = {"groove", "thread", "counterbore"}
COMPLEXITY_REVIEW_FEATURE_COUNT = 4


def apply_complexity_heuristic(parsed):
    features = parsed.get("features", [])
    reasons = []

    if len(features) > COMPLEXITY_REVIEW_FEATURE_COUNT:
        reasons.append(
            f"{len(features)} features detected (>{COMPLEXITY_REVIEW_FEATURE_COUNT}) - "
            f"complex drawings are more likely to have missed or misread features"
        )

    present_risky_types = {f.get("feature_type") for f in features} & COMPLEXITY_REVIEW_FEATURE_TYPES
    if present_risky_types:
        reasons.append(
            f"Contains feature type(s) prone to misreads: {', '.join(sorted(present_risky_types))}"
        )

    part_type = str(parsed.get("part_type", "")).upper()
    has_raised_face = any(f.get("feature_type") == "raised_face" for f in features)
    if "-FF-" in part_type or part_type.endswith("-FF") or "FLAT FACE" in part_type:
        if has_raised_face:
            reasons.append(
                "part_type indicates flat face (FF) but a raised_face feature was extracted - contradiction"
            )

    if reasons and not parsed.get("needs_review", False):
        parsed["needs_review"] = True
        heuristic_note = "Auto-flagged by complexity heuristic: " + "; ".join(reasons)
        existing = parsed.get("review_reason", "")
        parsed["review_reason"] = (existing + " | " + heuristic_note) if existing else heuristic_note

    return parsed


def validate_schema(parsed):
    problems = []
    for field in REQUIRED_TOP_LEVEL:
        if field not in parsed:
            problems.append(f"Missing top-level field: {field}")
    if "base_feature" in parsed and isinstance(parsed["base_feature"], dict):
        for field in REQUIRED_BASE_FEATURE:
            if field not in parsed["base_feature"]:
                problems.append(f"Missing base_feature field: {field}")
    elif "base_feature" in parsed:
        problems.append("base_feature is not an object")
    if "features" in parsed and not isinstance(parsed["features"], list):
        problems.append("features is not an array")
    return problems


def call_model(messages):
    response = client.chat.completions.create(
        model='Qwen/Qwen3.8-27B',
        messages=messages,
        max_tokens=2048,
        temperature=0,
        extra_body={
            'chat_template_kwargs': {'enable_thinking': False},
            'guided_json': FEATURE_SCHEMA,
        },
    )
    return response.choices[0].message.content


def extract_features(pdf_path, retry_on_schema_mismatch=True):
    pages = convert_from_path(pdf_path, dpi=300)
    buf = io.BytesIO()
    pages[0].save(buf, format='PNG')
    img_b64 = base64.b64encode(buf.getvalue()).decode()

    messages = [{
        'role': 'user',
        'content': [
            {'type': 'text', 'text': PROMPT},
            {'type': 'image_url', 'image_url': {'url': f'data:image/png;base64,{img_b64}'}}
        ]
    }]

    raw = call_model(messages)
    cleaned = strip_fences(raw)

    try:
        parsed = json.loads(cleaned)
    except json.JSONDecodeError as e:
        return {"error": f"JSON parse failed: {e}", "raw": raw, "retried": False}

    problems = validate_schema(parsed)

    if problems and retry_on_schema_mismatch:
        correction = (f"Your previous output did not match the required schema. "
                      f"Problems: {'; '.join(problems)}. "
                      f"Re-extract the same drawing and output ONLY valid JSON with "
                      f"exactly the required field names.")
        messages.append({'role': 'assistant', 'content': raw})
        messages.append({'role': 'user', 'content': correction})

        raw2 = call_model(messages)
        cleaned2 = strip_fences(raw2)
        try:
            parsed2 = json.loads(cleaned2)
            problems2 = validate_schema(parsed2)
            parsed2 = apply_complexity_heuristic(parsed2)
            return {"result": parsed2, "schema_valid": not problems2,
                    "problems": problems2, "retried": True}
        except json.JSONDecodeError as e:
            return {"error": f"JSON parse failed on retry: {e}", "raw": raw2, "retried": True}

    parsed = apply_complexity_heuristic(parsed)
    return {"result": parsed, "schema_valid": not problems,
            "problems": problems, "retried": False}


def run_batch(dataset_dir="raw_dataset", output_dir="extracted"):
    os.makedirs(output_dir, exist_ok=True)
    pdf_files = sorted(glob.glob(os.path.join(dataset_dir, "*.pdf")))

    print(f"Found {len(pdf_files)} drawings in {dataset_dir}\n")

    summary_rows = []

    for i, pdf_path in enumerate(pdf_files, 1):
        name = os.path.splitext(os.path.basename(pdf_path))[0]
        print(f"[{i}/{len(pdf_files)}] {name} ...", end=" ", flush=True)

        t0 = time.time()
        outcome = extract_features(pdf_path)
        elapsed = time.time() - t0

        out_path = os.path.join(output_dir, f"{name}.json")
        with open(out_path, "w") as f:
            json.dump(outcome, f, indent=2)

        if "error" in outcome:
            print(f"ERROR ({elapsed:.0f}s)")
            summary_rows.append({
                "drawing": name, "status": "ERROR", "schema_valid": False,
                "needs_review": None, "feature_count": None,
                "retried": outcome.get("retried", False), "seconds": round(elapsed, 1)
            })
            continue

        result = outcome["result"]
        n_features = len(result.get("features", []))
        needs_review = result.get("needs_review", None)
        schema_valid = outcome.get("schema_valid", False)

        status = "OK" if schema_valid else "SCHEMA_MISMATCH"
        print(f"{status}, {n_features} features, needs_review={needs_review} ({elapsed:.0f}s)")

        summary_rows.append({
            "drawing": name, "status": status, "schema_valid": schema_valid,
            "needs_review": needs_review, "feature_count": n_features,
            "retried": outcome.get("retried", False), "seconds": round(elapsed, 1)
        })

    summary_path = os.path.join(output_dir, "_summary.json")
    with open(summary_path, "w") as f:
        json.dump(summary_rows, f, indent=2)

    print(f"\n{'=' * 90}")
    print(f"{'Drawing':<45} {'Status':<16} {'Features':<10} {'Review':<8} {'Retry':<7} {'Sec':<6}")
    print(f"{'-' * 90}")
    for row in summary_rows:
        print(f"{row['drawing']:<45} {row['status']:<16} "
              f"{str(row['feature_count']):<10} {str(row['needs_review']):<8} "
              f"{str(row['retried']):<7} {row['seconds']:<6}")

    n_ok = sum(1 for r in summary_rows if r["status"] == "OK")
    n_error = sum(1 for r in summary_rows if r["status"] == "ERROR")
    n_mismatch = sum(1 for r in summary_rows if r["status"] == "SCHEMA_MISMATCH")
    n_review = sum(1 for r in summary_rows if r.get("needs_review") is True)
    n_retried = sum(1 for r in summary_rows if r.get("retried") is True)
    total_time = sum(r["seconds"] for r in summary_rows)

    print(f"{'-' * 90}")
    print(f"Total: {len(summary_rows)}  |  OK: {n_ok}  |  Schema mismatch: {n_mismatch}  |  Errors: {n_error}")
    print(f"Flagged needs_review: {n_review}/{len(summary_rows)}  |  Required retry: {n_retried}")
    print(f"Total time: {total_time:.0f}s ({total_time/60:.1f} min)")
    print(f"\nPer-drawing results saved to: {output_dir}/")
    print(f"Summary saved to: {summary_path}")


if __name__ == "__main__":
    run_batch()
